'''
A Convolutional Network implementation example using TensorFlow library.
This example is using the MNIST database of handwritten digits
(http://yann.lecun.com/exdb/mnist/)

Author: Aymeric Damien
Project: https://github.com/aymericdamien/TensorFlow-Examples/
'''

from random import randint
import argparse
import input_data
import os
import sys
import tensorflow as tf
import time


# Create some wrappers for simplicity
def conv2d(x, W, b, strides=1):
    # Conv2D wrapper, with bias and relu activation
    x = tf.nn.conv2d(x, W, strides=[1, strides, strides, 1], padding='SAME')
    x = tf.nn.bias_add(x, b)
    return tf.nn.relu(x)


def maxpool2d(x, k=2):
    # MaxPool2D wrapper
    return tf.nn.max_pool(x, ksize=[1, k, k, 1], strides=[1, k, k, 1],
                          padding='SAME')


# Create model
def conv_net(x, weights, biases, dropout):
    # MNIST data input is a 1-D vector of 784 features (28*28 pixels)
    # Reshape to match picture format [Height x Width x Channel]
    # Tensor input become 4-D: [Batch Size, Height, Width, Channel]
    x = tf.reshape(x, shape=[-1, 28, 28, 1])

    # Convolution Layer
    conv1 = conv2d(x, weights['wc1'], biases['bc1'])
    # Max Pooling (down-sampling)
    conv1 = maxpool2d(conv1, k=2)

    # Convolution Layer
    conv2 = conv2d(conv1, weights['wc2'], biases['bc2'])
    # Max Pooling (down-sampling)
    conv2 = maxpool2d(conv2, k=2)

    # Fully connected layer
    # Reshape conv2 output to fit fully connected layer input
    fc1 = tf.reshape(conv2, [-1, weights['wd1'].get_shape().as_list()[0]])
    fc1 = tf.add(tf.matmul(fc1, weights['wd1']), biases['bd1'])
    fc1 = tf.nn.relu(fc1)
    # Apply Dropout
    fc1 = tf.nn.dropout(fc1, dropout)
    # In future TensorFlow versions, rate flag is recommended instead of
    # keep_prob flag.
    # fc1 = tf.nn.dropout(fc1, rate=(1 - dropout))

    # Output, class prediction
    out = tf.add(tf.matmul(fc1, weights['out']), biases['out'])
    return out


def main(_):
    if (FLAGS.result_dir[0] == '$'):
        RESULT_DIR = os.environ[FLAGS.result_dir[1:]]
    else:
        RESULT_DIR = FLAGS.result_dir

    model_path = os.path.join(RESULT_DIR, 'model')

    if (FLAGS.data_dir[0] == '$'):
        DATA_DIR = os.environ[FLAGS.data_dir[1:]]
    else:
        DATA_DIR = FLAGS.data_dir

    # Add data dir to file path
    train_images_file = os.path.join(DATA_DIR, FLAGS.train_images_file)
    train_labels_file = os.path.join(DATA_DIR, FLAGS.train_labels_file)
    test_images_file = os.path.join(DATA_DIR, FLAGS.test_images_file)
    test_labels_file = os.path.join(DATA_DIR, FLAGS.test_labels_file)

    # Parameters
    learning_rate = FLAGS.learning_rate
    training_iters = FLAGS.training_iters
    batch_size = 128
    display_step = 10

    # This helps distinguish instances when the training job is restarted.
    instance_id = randint(0, 9999)

    # Import MINST data
    mnist = input_data.read_data_sets(train_images_file, train_labels_file,
                                      test_images_file, test_labels_file,
                                      one_hot=True)

    # Network Parameters
    n_input = 784  # MNIST data input (img shape: 28*28)
    n_classes = 10  # MNIST total classes (0-9 digits)
    dropout = 1  # Dropout, probability to keep units

    # tf Graph input
    x = tf.placeholder(tf.float32, [None, n_input], name='x_input')
    y = tf.placeholder(tf.float32, [None, n_classes], name='y_input')

    # Store layers weight & bias
    weights = {
        # 5x5 conv, 1 input, 32 outputs
        'wc1': tf.Variable(tf.random_normal([5, 5, 1, 32])),
        # 5x5 conv, 32 inputs, 64 outputs
        'wc2': tf.Variable(tf.random_normal([5, 5, 32, 64])),
        # fully connected, 7*7*64 inputs, 1024 outputs
        'wd1': tf.Variable(tf.random_normal([7*7*64, 1024])),
        # 1024 inputs, 10 outputs (class prediction)
        'out': tf.Variable(tf.random_normal([1024, n_classes]))
    }

    biases = {
        'bc1': tf.Variable(tf.random_normal([32])),
        'bc2': tf.Variable(tf.random_normal([64])),
        'bd1': tf.Variable(tf.random_normal([1024])),
        'out': tf.Variable(tf.random_normal([n_classes]))
    }

    # Construct model
    # logits = conv_net(x, weights, biases, keep_prob)
    logits = conv_net(x, weights, biases, dropout)
    pred = tf.nn.softmax(logits)

    # Define loss and optimizer
    cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(
                          logits=logits, labels=y))
    optimizer = (tf.train
                   .AdamOptimizer(learning_rate=learning_rate)
                   .minimize(cost))

    predictor = tf.argmax(pred, 1, name='predictor')

    # Evaluate model
    correct_pred = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

    # Initializing the variables
    init = tf.global_variables_initializer()

    # Launch the graph
    with tf.Session() as sess:
        sess.run(init)

        step = 1
        # Keep training until reach max iterations
        while step * batch_size < training_iters:
            batch_x, batch_y = mnist.train.next_batch(batch_size)
            # Run optimization op (backprop)
            sess.run(optimizer, feed_dict={x: batch_x,
                                           y: batch_y})
            if step % display_step == 0:

                # Calculate batch loss and accuracy
                loss, acc = sess.run([cost, accuracy],
                                     feed_dict={x: batch_x,
                                                y: batch_y})
                print('Time ' + '{:.4f}'.format(time.time()) +
                      ', instance ' + str(instance_id) +
                      ', Iter ' + str(step * batch_size) +
                      ', Minibatch Loss = ' + '{:.6f}'.format(loss) +
                      ', Training Accuracy = ' + '{:.2f}%'.format(acc*100))
                sys.stdout.flush()
            step += 1
        print('Optimization Finished!')

        # In future TensorFlow versions,
        # tf.compat.v1.saved_model.utils.build_tensor_info() should be used
        # instead of tf.saved_model.utils.build_tensor_info().
        # Especially in TensorFlow 2.0, a new object-based method of creating
        # SavedModels will be introduced.
        classification_inputs = tf.saved_model.utils.build_tensor_info(x)
        classification_outputs_classes =\
            tf.saved_model.utils.build_tensor_info(predictor)

        classification_signature = (
            tf.saved_model.signature_def_utils.build_signature_def(
                inputs={
                    tf.saved_model.signature_constants.CLASSIFY_INPUTS:
                        classification_inputs
                },
                outputs={
                    tf.saved_model.signature_constants.CLASSIFY_OUTPUT_CLASSES:
                        classification_outputs_classes
                },
                method_name=(tf
                             .saved_model
                             .signature_constants
                             .CLASSIFY_METHOD_NAME)
            )
        )

        print('classification_signature content:')
        print(classification_signature)

        # Calculate accuracy for 256 mnist test images
        print('Testing Accuracy: {:.2f}%'.format(
              sess.run(accuracy * 100,
                       feed_dict={
                           x: mnist.test.images[:256],
                           y: mnist.test.labels[:256]
                       })))

        builder = tf.saved_model.builder.SavedModelBuilder(model_path)
        legacy_init_op = tf.group(tf.tables_initializer(),
                                  name='legacy_init_op')
        builder.add_meta_graph_and_variables(
            sess, [tf.saved_model.tag_constants.SERVING],
            signature_def_map={
                'predict_images': classification_signature,
            },
            # In future TensorFlow versions, legacy_init_op flag
            # should not be included.
            legacy_init_op=legacy_init_op)

        save_path = str(builder.save())

        print('Model saved in file: %s' % save_path)

        os.system('(cd $RESULT_DIR/model;tar cvfz ../saved_model.tar.gz .)')
        print(str(os.listdir(os.environ['RESULT_DIR'])))
        print(os.environ['RESULT_DIR'])
        sys.stdout.flush()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    # environment variable when name starts with $
    parser.add_argument('--data_dir', type=str, default='$DATA_DIR',
                        help='Directory with data')
    parser.add_argument('--result_dir', type=str, default='$RESULT_DIR',
                        help='Directory with results')
    parser.add_argument('--train_images_file', type=str,
                        default='train_images.zip',
                        help='File name for train images')
    parser.add_argument('--train_labels_file', type=str,
                        default='train_labels.zip',
                        help='File name for train labels')
    parser.add_argument('--test_images_file', type=str,
                        default='test_images.zip',
                        help='File name for test images')
    parser.add_argument('--test_labels_file', type=str,
                        default='test_labels.zip',
                        help='File name for test labels')
    parser.add_argument('--training_iters', type=int, default=200000,
                        help='Number of training iterations')
    parser.add_argument('--learning_rate', type=int, default=0.001,
                        help='Learning rate')

    FLAGS, unparsed = parser.parse_known_args()

    print('Start model training')
    tf.app.run(main=main, argv=[sys.argv[0]] + unparsed)
